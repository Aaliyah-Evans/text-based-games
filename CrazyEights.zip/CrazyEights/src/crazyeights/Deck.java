/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crazyeights;

/**
 *
 * @author aaliy
 */

public class Deck extends CardCollection {

    public Deck(String name) {
        super(name);

        for (int suit = 0; suit <= 3; suit++) {
            for (int rank = 1; rank <= 13; rank++) {
                Cards.add(new Card(rank, suit));
            }
        }
    }
}