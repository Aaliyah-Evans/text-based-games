
package tictactoegame;

import java.util.Random;
import java.util.Scanner;



/**
 *
 * @author aaliyah
 */
public class TicTacToeGame {

   
    public static void main(String[] args) {
        
        int playOption;
        Random randomNumber = new Random();
        int n = randomNumber.nextInt(2) + 0;
        Scanner Crow = new Scanner(System.in);
        gameBoard ticTacToe = new gameBoard();
        String Introduction = "Welcome to Tic-Tac-Toe.\n"
        + "The first player is the X.\n"
        + "The second player is the O.\n"
        + "Please enter your row and then column number when asked.\n"
        + "Please note the first number is not one, it is zero!\n"
        + "Lastly, you may quit by entering a 7 at both the row AND at the column prompts."
        + "\nPlease enter a 1 to play with two players, or a 2 to play by yourself with a computer."       ;
        System.out.println(Introduction);
        playOption = Crow.nextInt();
       
        // if player choses two player mode
        if (playOption == 1) {
        ticTacToe.createBlankBoard();
        do 
        {
            System.out.println("Current board layout:");
            ticTacToe.printGameBoard();
            int row;
            int column;
            do
            {
                System.out.println("Player " + ticTacToe.getCurrentPlayer()+ ", it's your turn. Please chose the row you want to place your symbol."
                        + "\nRemember, the rows run from 0 to 2, up to down.");
                row = Crow.nextInt();
                System.out.println("Please chose the column. The columns run from 0 to 2, left to right.");
                column = Crow.nextInt();
                if((row == 7) && (column == 7)){
                    System.exit(0);
                }
                
            }
 
            while (!ticTacToe.placeTicTac(row, column));
            ticTacToe.switchPlayer();
        }
        while(!ticTacToe.isWinner() && !ticTacToe.isBoardFull());
        if (ticTacToe.isBoardFull() && !ticTacToe.isWinner())
        {
            System.out.println("The game is a tie! Until next time ☺ ");
        }
        else
        {
            ticTacToe.printGameBoard();
            ticTacToe.switchPlayer();
            System.out.println("Player " + ticTacToe.getCurrentPlayer()+ " is the winner!");
        }
        }
        
        



// if player v. computer mode is chosen
        if (playOption == 2) {
             ticTacToe.createBlankBoard();
             do {
            System.out.println("Current board layout:");
            ticTacToe.printGameBoard();
            int row;
            int column;
            do
            {
                System.out.println("Player " + ticTacToe.getCurrentPlayer()+ ", it's your turn. Please chose the row you want to place your symbol."
                        + "\nRemember, the rows run from 0 to 2, up to down.");
                row = Crow.nextInt();
                System.out.println("Please chose the column. The columns run from 0 to 2, left to right.");
                column = Crow.nextInt();
                if((row == 7) && (column == 7)){
                    System.exit(0);
                }
               
            }
            while (!ticTacToe.placeTicTac(row, column));
               ticTacToe.switchPlayer();
               ticTacToe.computerTurn();
        } while(!ticTacToe.isWinner() && !ticTacToe.isBoardFull());
        if (ticTacToe.isBoardFull() && !ticTacToe.isWinner())
        {
            System.out.println("The game is a tie! Until next time ☺ ");
        }
        else
        {
            ticTacToe.printGameBoard();         
            System.out.println("Player " + ticTacToe.getCurrentPlayer()+ " is the winner!");
        }
             
             
        }
    
}
}