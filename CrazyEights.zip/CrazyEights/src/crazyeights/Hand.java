/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crazyeights;

import java.util.ArrayList;

/**
 *
 * @author aaliy
 */
public class Hand extends CardCollection {

public Hand(String name) {
        super(name);
       
        
    }

  public void display() {
       System.out.println(getName() + ": ");
       for (int i = 0; i < getSize(); i++) {
           System.out.println(getCardFromDeck(i));
        }
        System.out.println();   
    }


}
