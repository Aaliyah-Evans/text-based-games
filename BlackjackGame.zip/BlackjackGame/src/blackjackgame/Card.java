
package blackjackgame;

/**
 *
 * @author aaliy
 */
class Card {
    
    private cardSuits Suit;
    private cardRanks Rank;
    
    public Card(cardSuits Suit, cardRanks Rank) {
    this.Rank = Rank;
    this.Suit = Suit;
     }
    
    @Override
    public String toString() {
    return this.Rank.toString() +  " of " + this.Suit.toString();
    }
    
    public cardRanks getRank() {
    return this.Rank;
    }
    
}
    


























