package blackjackgame;

import java.util.Scanner;

/**
 *
 * @author aaliyah
 */
public class BlackjackGame {

   
    
    public static void main(String[] args) {
      
        boolean continueGame = true;
        
        System.out.println("It's time to play Blackjack!");
        Deck cardDeck = new Deck();
        cardDeck.createNewDeck();
        cardDeck.shuffleDeck();
        Scanner Crow = new Scanner(System.in);
       
        
        // hands for both the player and the dealer
        Deck playerHand = new Deck();
        Deck dealerHand = new Deck();
        
        while (continueGame == true) {
        boolean endOfRound = false;
            
           
            playerHand.drawCard(cardDeck);
            playerHand.drawCard(cardDeck);
            
            dealerHand.drawCard(cardDeck);
            dealerHand.drawCard(cardDeck);
           
            
            while(true) {
                System.out.println("\nYour hand currently has these cards: ");
                System.out.println(playerHand);
                System.out.println("\nThe total value of the cards in your deck is " + playerHand.handValue() + ".");    
            
                System.out.println("\nThe dealer's hand currently has these cards: " + dealerHand.getCardFromDeck(0).toString() + ". The other card is hidden from your view.");
                System.out.println("Would you like to draw a card?"
                        + "\nPress 1 to draw a card."
                        + "\nPress 2 to stand.");
                int userInput = Crow.nextInt();
                if(userInput == 1){
                    playerHand.drawCard(cardDeck);
                    System.out.println("\nYou drew the " + playerHand.getCardFromDeck(playerHand.getDeckSize() - 1).toString() + ".");
                    if (playerHand.handValue() > 21) {
                        System.out.println("\nIt was a bust! The total value of your hand is " + playerHand.handValue() + ".");
                        endOfRound = true;
                      } 
                   
                }
            
          
                if (userInput == 2) {
                    break;
                }
            }
            
                 System.out.println("\nThe dealer's hand currently looks like this: " + dealerHand.toString() + ".");
                 if ((dealerHand.handValue() > playerHand.handValue()) && endOfRound == false) {
                     System.out.println("\nYou lose! The dealer was closer to 21.");
                        endOfRound = true;
                 }
                 
                 while ((dealerHand.handValue() < 17) && endOfRound == false) {                    
                    dealerHand.drawCard(cardDeck);
                     System.out.println("\nThe dealer draws from the deck a " + dealerHand.getCardFromDeck(dealerHand.getDeckSize() - 1).toString() + ".");
                 }
                 
                 System.out.println("\nThe total value of the dealer's hand is " + dealerHand.handValue() + ".");
                 if ((dealerHand.handValue() > 21) && endOfRound == false) {
                      System.out.println("\nIt was a bust for the dealer! You won this round.");
                      endOfRound = true;
                      
                      
                  
                 }
                 
                 if ((playerHand.handValue() == dealerHand.handValue()) && endOfRound == false) {
                     System.out.println("\nThe values of both your hand and the dealer's hand are the same.");
                     endOfRound = true;
                     
                 }
                    
                
        
        
                 if ((playerHand.handValue() > dealerHand.handValue()) && endOfRound == false) {
                     System.out.println("\nYou win!");
                     endOfRound = true;
                      
                 }
                else if(endOfRound == false) //dealer wins
			{
				System.out.println("\nDealer wins!"); 
                                endOfRound = true;
                }
                 
                        playerHand.moveCards(cardDeck);
                 dealerHand.moveCards(cardDeck);
                 System.out.println("\nEnd of hand."
                         + "\n--------------------------------------------");
            }
        
            
               
        }
        
    }
  

