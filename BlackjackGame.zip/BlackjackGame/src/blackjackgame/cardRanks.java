
package blackjackgame;


/**
 *
 * @author aaliy
 */
public enum cardRanks {
 
  Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King
}




























