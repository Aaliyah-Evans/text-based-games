
package tictactoegame;

import java.util.Random;

/**
 *
 * @author aaliy
 */
public class gameBoard {
    
    Random randomNumber = new Random();
    private char[][] gameBoard;
    private char currentPlayer;

    public gameBoard() { 
        gameBoard = new char[3][3];
        currentPlayer = 'X';
        createBlankBoard();
    }

    //Gives us access to currentPlayerMark
    public char getCurrentPlayer()
    {
        return currentPlayer;
    }


    // creates a blank board
    public void createBlankBoard() {

        // Loop through rows
        for (int i = 0; i < 3; i++) {

            // Loop through columns
            for (int j = 0; j < 3; j++) {
                gameBoard[i][j] = ' ';
            }
        }
    }
    
    public int getPlayerNumber(int playerNumber) {
if (currentPlayer == 'X') {
            playerNumber = 1;
        } else {
         playerNumber = 2;
}
    
    return playerNumber;
    }

 
    public void printGameBoard() {
        System.out.println("-------------");  
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(gameBoard[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
        
    }


    // checks to see if the board is full
    public boolean isBoardFull() {
        boolean isFull = true;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (gameBoard[i][j] == ' ') {
                    isFull = false;
                }
            }
        }

        return isFull;
    }


    // calls the other functions to see if any of them are full! a player is the winner if any return true.
    public boolean isWinner() {
        return (checkRows() || checkColumns() || checkDiagonals());
    }


    // Loop through rows and see if any are winners.
    private boolean checkRows() {
        for (int i = 0; i < 3; i++) {
            if (checkSameIcon(gameBoard[i][0], gameBoard[i][1], gameBoard[i][2]) == true) {
                return true;
            }
        }
        return false;
    }

    
    
    // checks the columns to see if any yield a winner.
    private boolean checkColumns() {
        for (int i = 0; i < 3; i++) {
            if (checkSameIcon(gameBoard[0][i], gameBoard[1][i], gameBoard[2][i]) == true) {
                return true;
            }
        }
        return false;
    }


    // checks diagonally to see if there is a winner.
    private boolean checkDiagonals() {
        return ((checkSameIcon(gameBoard[0][0], gameBoard[1][1], gameBoard[2][2]) == true) || (checkSameIcon(gameBoard[0][2], gameBoard[1][1], gameBoard[2][0]) == true));
    }


    // checks rows and columns to see if the char within them are the same.
    private boolean checkSameIcon(char char1, char char2, char char3) {
        return ((char1 != ' ') && (char1 == char2) && (char2 == char3));
    }


    // changes the player depending on whose turn it was last
    public void switchPlayer() {
            if (currentPlayer == 'X') {
            currentPlayer = 'O';
        }
        else {
            currentPlayer = 'X';
        }
    }

    // puts X or O in spot chosen by player
    public boolean placeTicTac(int row, int col) {

       // makes sure that the rows and columns chosen are actually legal.
        if ((row >= 0) && (row < 3)) {
            if ((col >= 0) && (col < 3)) {
                if (gameBoard[row][col] == ' ') {
                    gameBoard[row][col] = currentPlayer;
                    return true;
                }
            }
        }

        return false;
    }
        

    public boolean checkForComputerTurn(int row, int col) {
        if (currentPlayer == 'O' && !isBoardFull()) { 
             {
            }
            row = randomNumber.nextInt(3) + 0;
            col = randomNumber.nextInt(3) + 0;
            if ((row >= 0) && (row < 3)) {
            if ((col >= 0) && (col < 3)) {
                if (gameBoard[row][col] == ' ') {
                    gameBoard[row][col] = currentPlayer;
                    return true;
                    } 
                makeValidMove(row, col);
            }
        } 
                 }

        
         return false;
    
  
    }
    
//    1
    
    public void makeValidMove(int row, int col) {
    if(currentPlayer == 'O') {
        if (gameBoard[row][col] == 'X' || gameBoard[row][col] == 'O' ) {
            checkForComputerTurn(row, col);
        }
    
    }
    
    }
    
    public void computerTurn() {
            checkForComputerTurn(0,0);
            switchPlayer();
    
    }
}
    
