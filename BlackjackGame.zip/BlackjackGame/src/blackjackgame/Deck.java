
package blackjackgame;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author aaliy
 */
public class Deck {
    
    private ArrayList<Card> Cards;
    
    public Deck() {
    this.Cards = new ArrayList<Card>();
    }
    
public void createNewDeck() {
    for(cardSuits cardSuit : cardSuits.values()) {
        for (cardRanks cardRank : cardRanks.values() ) {
            this.Cards.add(new Card(cardSuit, cardRank));
}
}
}    

    @Override
    public String toString() {
    String listCards = "";
    for(Card playingCard : this.Cards) {
    listCards += "\n" + playingCard.toString();
    }
    return listCards;
}
    
public void shuffleDeck() {
ArrayList<Card> tempDeck = new ArrayList<Card>();
Random shuffler = new Random();
int indexOfRandomCard = 0;
int DeckSize = this.Cards.size();
    for (int i = 0; i < DeckSize; i++) {
        indexOfRandomCard = shuffler.nextInt((this.Cards.size()- 1 - 0) + 1) + 0;
        tempDeck.add(this.Cards.get(indexOfRandomCard));
        this.Cards.remove(indexOfRandomCard);
    }
    this.Cards = tempDeck;
}

public int getDeckSize() {
 return this.Cards.size();

}

public void moveCards(Deck targetDeck) {
    int deckSize = this.Cards.size();
    for (int i = 0; i < deckSize; i++) {
        targetDeck.addCard(this.getCardFromDeck(i));
    }
        for(int i = 0; i < deckSize; i++){
        this.removeCardFromDeck(0);
        }
    
}

public int handValue() {
    int handValue = 0;
    int Aces = 0;
    
    for(Card playingCard : this.Cards){
    switch(playingCard.getRank()) {
        case Ace: 
             Aces += 1;
             break;
        case Two:
             handValue += 2;
             break;
        case Three:
             handValue += 3;
             break;
        case Four:
             handValue += 4;
             break;
        case Five:
             handValue += 5;
             break;  
        case Six:
             handValue += 6;
             break;  
        case Seven:
             handValue += 7;
             break;  
        case Eight:
             handValue += 8;
             break;
        case Nine:
             handValue += 9;
             break;
        case Ten:
             handValue += 10;
             break;
        case Jack:
             handValue += 10;
             break;
        case Queen:
             handValue += 10;
             break;
        case King:
             handValue += 10;
             break;     
    }
    }
    for (int i = 0; i < Aces; i++) {
        if (handValue > 10) {
            handValue += 1;
        }
        else{
         handValue += 11;
        }
    }
    return handValue;
}

public void removeCardFromDeck(int card){
this.Cards.remove(card);
}

public Card getCardFromDeck(int card) {
return this.Cards.get(card);
}

public void addCard(Card card) {
 this.Cards.add(card);
}

public void drawCard(Deck playingDeck) {
this.Cards.add(playingDeck.getCardFromDeck(0));
playingDeck.removeCardFromDeck(0);
}
}
