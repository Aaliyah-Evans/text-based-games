/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crazyeights;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author aaliy
 */
class CardCollection {
    
    private String name;
    ArrayList<Card> Cards;
    
    public CardCollection(String name) {
        this.name = name;
        this.Cards = new ArrayList<Card>();
    }

    public String getName() {
        return name;
    }

  
    public void display(Player player) {
       System.out.println(player.getName() + ": ");
       for (int i = 0; i < getSize(); i++) {
           System.out.println(getCardFromDeck(i));
        }
        System.out.println();   
    }
    
    
    public void dealCards(CardCollection that, int n) {
    for (int i = 0; i < n; i++) {
        Card card = putCardOnTop();
        that.addCard(card);
}
    }
    
    public void dealAllCards(CardCollection that) {
        int i = getSize();
        dealCards(that, i);
    }
    
    public void switchCard(int a, int b) {
        Card tempCard = Cards.get(a);
        Cards.set(a, Cards.get(b));
        Cards.set(b, tempCard);
  }
   
   
    public boolean isEmpty() {
        return Cards.size() == 0;
    }
    
    public void addCard(Card card) {
        Cards.add(card);
    }
    
    public int getSize() {
        return Cards.size();
    }
    
    public Card getCardFromDeck(int card) {
        return Cards.get(card);
    }
    
    public Card putCardOnTop(int card) {
        return Cards.remove(card);
    }
    
    public Card putCardOnTop() {
        int card = getSize() - 1;
        return putCardOnTop(card);
}
    
    
    public Card getLastCard() {
        int lastCard = getSize() - 1;
        return Cards.get(lastCard);
    }
    
    public void shuffle() {
        Random shuffler = new Random();
            for (int i = getSize() - 1; i > 0; i--) {
            int j = shuffler.nextInt(i);
                switchCard(i, j);
    }
}
   







} 

