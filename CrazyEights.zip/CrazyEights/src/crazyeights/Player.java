package crazyeights;

/**
 *
 * @author aaliy
 */

public class Player {

private String name;
private Hand hand;

public Player(String name) {
    this.name = name;
    this.hand = new Hand(name);
    }
    
public Card searchForMatchingCard(Card previousCard) {
    for (int i = 0; i < hand.getSize(); i++) {
        Card card = hand.getCardFromDeck(i);
        if (isCardAMatch(card, previousCard)) {
        return hand.putCardOnTop(i);
        }
    }
        return null;
}
  
public Card drawForMatchingCard(Eights Eights, Card prev) {
    while (true) {
        Card card = Eights.drawCard();
        System.out.println(name + " draws " + card);
        if (isCardAMatch(card, prev)) {
            return card;
        }
        hand.addCard(card);
    }
}

public static boolean isCardAMatch(Card firstCard, Card secondCard) {
    if (firstCard.getSuit() == secondCard.getSuit()) {
        return true;
    }
    if (firstCard.getRank() == secondCard.getRank()) {
        return true;
    }
    if (firstCard.getRank() == 8) {
        return true;
    }
    return false;
}

    public String getName() {
        return name;
    }
   
    public CardCollection getHand() {
        return hand;
    }

public Card playCrazyEights(Eights Eights, Card previousCard) {
    Card currentCard = searchForMatchingCard(previousCard);
    if (currentCard == null) {
        currentCard = drawForMatchingCard(Eights, previousCard);
    }
    return currentCard;
}

public void display(Player player) {
    hand.display(player);
    
}

}