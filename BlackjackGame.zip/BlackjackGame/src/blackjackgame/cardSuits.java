
package blackjackgame;

/**
 *
 * @author aaliy
 */
public enum cardSuits {
    
    Clubs, Diamonds, Hearts, Spades
}
