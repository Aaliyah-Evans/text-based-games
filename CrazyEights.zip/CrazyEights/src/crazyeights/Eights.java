package crazyeights;

import java.util.Scanner;

/**
 *
 * @author aaliy
 */
public class Eights {
   private Player playerOne;
   private Player playerTwo;
   private Hand drawPile = new Hand("Draw Pile");
   private Hand discardPile =  new Hand("Discard Pile");
   private Scanner Crow;
    
public void reshuffleCards() {
    Card prev = discardPile.putCardOnTop();
    discardPile.dealAllCards(drawPile);
    discardPile.addCard(prev);
    drawPile.shuffle();
}
   
   public Eights() {
    Deck deck = new Deck("Deck");
    deck.shuffle();
    int handSize = 5;
    playerOne = new Player("Player One");
    deck.dealCards(playerOne.getHand(), handSize);

    playerTwo = new Player("Player Two");
    deck.dealCards(playerTwo.getHand(), handSize);

    discardPile = new Hand("Discard Pile");
    deck.dealCards(discardPile, 1);

    drawPile = new Hand("Draw Pile");
    deck.dealAllCards(drawPile);

    Crow = new Scanner(System.in);
}
  
public boolean isDone() {
    return playerOne.getHand().isEmpty() || playerTwo.getHand().isEmpty();
}


public Card drawCard() {
    if (drawPile.isEmpty()) {
        reshuffleCards();
    }
    return drawPile.putCardOnTop();
}

public Player nextPlayer(Player current) {
    if (current == playerOne) {
        return playerTwo;
    } else {
        return playerOne;
    }
}

public void takeTurn(Player player) {
    Card prev = discardPile.getLastCard();
    Card next = player.playCrazyEights(this, prev);
    discardPile.addCard(next);

    System.out.println(player.getName() + " puts down the " + next + ".");
    System.out.println();
}

public void playGame() {
    Player player = playerOne;
    
    // keep playing until there's a winner
    while (!isDone()) {
        displayState();
        waitForUser();
        takeTurn(player);
        player = nextPlayer(player);
    }
    player = nextPlayer(player);
    System.out.println(player.getName() + " wins the game!");
}

public void displayState() {
    playerOne.display(playerOne);
    playerTwo.display(playerTwo);
    discardPile.getName();
    discardPile.display();
    System.out.println("Draw Pile:");
    System.out.println(drawPile.getSize() + " cards"
            + "\nPlease press enter to continue.");
}

public void waitForUser() {
    Crow.nextLine();
}
}
