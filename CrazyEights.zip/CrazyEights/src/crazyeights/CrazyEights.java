
package crazyeights;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author aaliyah, alexia, and priscila
 */
public class CrazyEights {

   
  
    public static void main(String[] args) {
    
   Eights Game = new Eights();

   Game.playGame();
        
        
        
        
    }
}
